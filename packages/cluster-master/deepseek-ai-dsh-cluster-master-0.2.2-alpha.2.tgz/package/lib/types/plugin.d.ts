/** Cordis service mounting the Cluster Master reverse tunnel and relay on the WebServer. */
import { Service, type Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
import { WorkerRegistry } from './registry.ts';
import { MasterRelay } from './relay.ts';
export interface Config {
    /** Pre-shared secret token required from workers during handshake. */
    readonly authToken: string;
    /** WebSocket endpoint path for worker reverse connection. */
    readonly workerConnectPath?: string;
    /** Cadence of heartbeat ping frames in milliseconds. */
    readonly heartbeatIntervalMs?: number;
    /** Maximum consecutive unanswered pings before worker is pruned. */
    readonly maxMissedPongs?: number;
}
declare module '@deepseek-ai/cordis' {
    interface Context {
        /** Cluster Master service instance. */
        clusterMaster: ClusterMasterService;
    }
}
/** Cluster Master Cordis service managing remote worker registrations and proxying browser traffic. */
export declare class ClusterMasterService extends Service {
    static inject: string[];
    static Config: z<Config>;
    readonly registry: WorkerRegistry;
    readonly relay: MasterRelay;
    private readonly workerWss;
    /**
     * @param ctx - Host context.
     * @param config - Cluster master configuration.
     */
    constructor(ctx: Context, config: Config);
    /** Tear down relay, web socket server and worker registry connections. */
    dispose(): void;
}
export default ClusterMasterService;
//# sourceMappingURL=plugin.d.ts.map